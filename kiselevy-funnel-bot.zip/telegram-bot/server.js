// server.js — Основной сервер платформы воронок

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const TelegramBot = require('node-telegram-bot-api');
const FunnelEngine = require('./funnel-engine');
const path = require('path');
const fs = require('fs');

// ============ КОНФИГ ============
const PORT = process.env.PORT || 3000;
const BOT_TOKEN = process.env.BOT_TOKEN;
const ADMIN_ID = process.env.ADMIN_ID ? parseInt(process.env.ADMIN_ID) : null;
const NATALIA_ID = process.env.NATALIA_ID ? parseInt(process.env.NATALIA_ID) : null;

// Простое файловое хранилище (для MVP, потом заменим на Supabase)
class FileStorage {
  constructor(dir = './data') {
    this.dir = dir;
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  }

  _path(key) { return path.join(this.dir, key.replace(/:/g, '_') + '.json'); }

  async get(key) {
    try {
      return fs.readFileSync(this._path(key), 'utf-8');
    } catch { return null; }
  }

  async set(key, value) {
    fs.writeFileSync(this._path(key), value, 'utf-8');
    return true;
  }

  async del(key) {
    try { fs.unlinkSync(this._path(key)); } catch {}
    return true;
  }

  // Загрузить все воронки
  async loadFunnels() {
    const funnels = [];
    const funnelDir = path.join(__dirname, 'funnels');
    if (!fs.existsSync(funnelDir)) return funnels;
    const files = fs.readdirSync(funnelDir).filter(f => f.endsWith('.json'));
    for (const file of files) {
      try {
        const data = JSON.parse(fs.readFileSync(path.join(funnelDir, file), 'utf-8'));
        funnels.push(data);
      } catch (e) {
        console.error('Ошибка загрузки воронки', file, e.message);
      }
    }
    return funnels;
  }
}

// ============ ИНИЦИАЛИЗАЦИЯ ============
const app = express();
const storage = new FileStorage();
const engine = new FunnelEngine(storage);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ============ TELEGRAM БОТ ============
let bot = null;
if (BOT_TOKEN) {
  bot = new TelegramBot(BOT_TOKEN, { polling: true });
  console.log('🤖 Бот запущен и слушает сообщения...');
}

// ============ ФУНКЦИИ ПОМОЩНИКИ ============

/**
 * Отправить результат выполнения блока пользователю
 */
async function sendBlockResult(chatId, result) {
  if (result.isEnd) {
    await bot.sendMessage(chatId, result.content || '✅ Воронка завершена!');
    return;
  }

  if (result.delay) {
    // Задержка — не отправляем, просто ждём
    setTimeout(async () => {
      const nextResult = await engine.continueFunnel(chatId.toString(), '__delay__');
      if (nextResult) await sendBlockResult(chatId, nextResult);
    }, result.delay);
    return;
  }

  if (!result.content && result.type === 'tag') {
    // Тег — тихое действие, просто продолжаем
    const nextResult = await engine.continueFunnel(chatId.toString(), '__tag__');
    if (nextResult) await sendBlockResult(chatId, nextResult);
    return;
  }

  if (result.buttons && result.buttons.length > 0) {
    const keyboard = {
      reply_markup: {
        keyboard: result.buttons.map(b => [{ text: b }]),
        resize_keyboard: true,
        one_time_keyboard: true
      }
    };
    await bot.sendMessage(chatId, result.content, keyboard);
  } else {
    await bot.sendMessage(chatId, result.content);
  }
}

// ============ TELEGRAM ОБРАБОТЧИК ============
if (bot) {
  // Команда /start — запуск воронки (или показать меню)
  bot.onText(/\/start(?:\s+(.+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    const commandArg = match[1] || '';

    // Приветственное сообщение
    await bot.sendMessage(chatId,
      `👋 Добро пожаловать!\n\nЯ — бот платформы автоворонок KISELEVY CREO.\n\nДоступные команды:\n/help — помощь\n/funnels — список воронок\n/start_demo — пройти демо-воронку`,
      { reply_markup: { remove_keyboard: true } }
    );
  });

  // Команда /help
  bot.onText(/\/help/, async (msg) => {
    const chatId = msg.chat.id;
    await bot.sendMessage(chatId,
      `📋 *Как это работает*\n\nЯ провожу вас по сценарию автоматической воронки: сообщения, вопросы, лид-магниты, условия.\n\nКоманды:\n/funnels — все доступные воронки\n/start_demo — демо-воронка "Чек-лист"\n/reset — сбросить активную воронку\n\nПросто отвечайте на мои сообщения — и я поведу вас дальше.`,
      { parse_mode: 'Markdown' }
    );
  });

  // Команда /funnels
  bot.onText(/\/funnels/, async (msg) => {
    const chatId = msg.chat.id;
    const funnels = await storage.loadFunnels();
    if (funnels.length === 0) {
      await bot.sendMessage(chatId, '📭 Пока нет активных воронок.');
      return;
    }
    let text = '*Доступные воронки:*\n\n';
    funnels.forEach(f => {
      text += `• ${f.name} — ${f.status === 'active' ? '✅ активна' : '📄 черновик'}\n`;
    });
    await bot.sendMessage(chatId, text, { parse_mode: 'Markdown' });
  });

  // Команда /start_demo
  bot.onText(/\/start_demo/, async (msg) => {
    const chatId = msg.chat.id;
    const funnels = await storage.loadFunnels();
    const demoFunnel = funnels.find(f => f.name && f.name.includes('Чек-лист')) || funnels[0];
    if (!demoFunnel) {
      await bot.sendMessage(chatId, '❌ Демо-воронка не найдена. Загрузите воронку в папку funnels/');
      return;
    }
    const result = await engine.startFunnel(demoFunnel, chatId.toString(), { channel: 'telegram', name: msg.from.first_name });
    await sendBlockResult(chatId, result);
  });

  // Команда /reset
  bot.onText(/\/reset/, async (msg) => {
    const chatId = msg.chat.id;
    const activeFunnelId = await storage.get(`funnel:${chatId}:active`);
    if (activeFunnelId) {
      await engine.finishFunnel(chatId.toString(), activeFunnelId);
      await bot.sendMessage(chatId, '🔄 Текущая воронка сброшена. Начните новую командой /start_demo');
    } else {
      await bot.sendMessage(chatId, 'ℹ️ Нет активной воронки для сброса.');
    }
  });

  // Обработка всех текстовых сообщений (продолжение воронки)
  bot.on('message', async (msg) => {
    const chatId = msg.chat.id;

    // Пропускаем команды
    if (msg.text && msg.text.startsWith('/')) return;

    // Пробуем продолжить активную воронку
    const result = await engine.continueFunnel(chatId.toString(), msg.text);
    if (result) {
      await sendBlockResult(chatId, result);
    }
    // Если нет активной воронки — бот просто молчит
    // (пользователь не запускал /start_demo)
  });

  // Обработка ошибок
  bot.on('polling_error', (error) => {
    console.error('Polling error:', error.message);
  });
}

// ============ REST API ============

// Получить все воронки
app.get('/api/funnels', async (req, res) => {
  try {
    const funnels = await storage.loadFunnels();
    res.json({ ok: true, funnels });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

// Получить одну воронку
app.get('/api/funnels/:id', async (req, res) => {
  try {
    const funnels = await storage.loadFunnels();
    const funnel = funnels.find(f => f.id === req.params.id);
    if (!funnel) return res.status(404).json({ ok: false, error: 'Воронка не найдена' });
    res.json({ ok: true, funnel });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

// Сохранить воронку
app.post('/api/funnels', async (req, res) => {
  try {
    const funnel = req.body;
    if (!funnel.id) funnel.id = require('uuid').v4();
    fs.writeFileSync(
      path.join(__dirname, 'funnels', `${funnel.id}.json`),
      JSON.stringify(funnel, null, 2),
      'utf-8'
    );
    res.json({ ok: true, id: funnel.id });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

// Здоровье сервера
app.get('/api/health', (req, res) => {
  res.json({ ok: true, uptime: process.uptime(), bot: !!bot });
});

// ============ ФРОНТЕНД ============
// Отдаём HTML-платформу, если есть папка public
// Если нет — показываем приветствие
app.get('/', (req, res) => {
  const publicIndex = path.join(__dirname, 'public', 'index.html');
  if (fs.existsSync(publicIndex)) {
    res.sendFile(publicIndex);
  } else {
    res.send(`
      <!DOCTYPE html>
      <html><body style="font-family:sans-serif;background:#1e2a38;color:#fff;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;">
        <div style="text-align:center;">
          <h1>🚀 Платформа воронок KISELEVY CREO</h1>
          <p>Сервер работает. Загрузите HTML-платформу в папку <code>public/</code></p>
          <p style="color:#9aa6b2;">API: <a href="/api/health" style="color:#4fb8e8;">/api/health</a></p>
        </div>
      </body></html>
    `);
  }
});

// ============ ЗАПУСК ============
app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n🚀 Платформа воронок KISELEVY CREO`);
  console.log(`📡 Сервер: http://0.0.0.0:${PORT}`);
  console.log(`🔗 API:   http://localhost:${PORT}/api/health`);
  console.log(`🤖 Бот:   ${bot ? '✅ активен' : '❌ не настроен (нет BOT_TOKEN)'}`);
});
