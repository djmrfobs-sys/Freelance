# README.md

# 🚀 Платформа воронок KISELEVY CREO

Автоматические воронки продаж в Telegram. Конструктор + CRM + Telegram-бот.

## 🏗 Структура проекта

```
├── server.js            # Основной сервер (Express + Telegram bot)
├── funnel-engine.js     # Движок воронок (прохождение блоков)
├── package.json         # Зависимости
├── .env.example         # Шаблон переменных окружения
├── funnels/             # JSON-файлы воронок
│   └── demo-funnel.json # Демо-воронка
└── public/              # HTML-платформа (фронтенд)
```

## 🚀 Быстрый старт

### 1. Настройка

```bash
cp .env.example .env
# Отредактируйте .env — вставьте BOT_TOKEN от @BotFather
```

### 2. Установка и запуск

```bash
npm install
npm start
```

### 3. Команды Telegram-бота

- `/start` — приветствие
- `/help` — помощь
- `/funnels` — список воронок
- `/start_demo` — запустить демо-воронку
- `/reset` — сбросить текущую воронку

## 🧩 Типы блоков воронки

| Тип | Описание |
|-----|----------|
| trigger | Стартовый блок (без входа) |
| message | Текстовое сообщение |
| buttons | Кнопки выбора |
| leadmagnet | Выдача файла/материала |
| condition | Условие (Да/Нет) |
| payment | Ссылка на оплату |
| delay | Пауза перед следующим шагом |
| tag | Присвоить метку клиенту |
| action | Webhook / CRM-интеграция |
| handoff | Передача оператору |
| end | Конец ветки |

## 🌐 API

| Метод | Путь | Описание |
|-------|------|----------|
| GET | `/api/health` | Здоровье сервера |
| GET | `/api/funnels` | Все воронки |
| GET | `/api/funnels/:id` | Одна воронка |
| POST | `/api/funnels` | Сохранить воронку |

## ☁️ Деплой на Render

1. Залить код на GitHub (репозиторий `Kiselevy_lid_bot`)
2. На Render → New Web Service → подключить репозиторий
3. Build Command: `npm install`
4. Start Command: `node server.js`
5. Добавить переменные окружения в Render Dashboard: `BOT_TOKEN`, `ADMIN_ID`, `NATALIA_ID`

## 🗺 Планы развития

- [ ] Папка `public/` с HTML-платформой (конструктор + CRM)
- [ ] Supabase вместо файлового хранилища
- [ ] Instagram-интеграция (Meta API)
- [ ] WhatsApp-интеграция
- [ ] Платёжный модуль (ЮKassa / Tinkoff)
