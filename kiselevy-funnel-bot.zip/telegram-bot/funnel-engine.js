# funnel-engine.js — Движок воронок

const { v4: uuidv4 } = require('uuid');

/**
 * Движок для прохождения воронок
 * Воронка = directed graph из блоков (nodes) и связей (connections)
 */

class FunnelEngine {
  constructor(storage) {
    this.storage = storage; // объект с get/set для сохранения состояний
  }

  // === ТИПЫ БЛОКОВ ===
  // trigger    — старт (нет входа)
  // message    — сообщение
  // buttons    — кнопки выбора
  // leadmagnet — лид-магнит (файл/материал)
  // condition  — условие (да/нет)
  // payment    — оплата
  // delay      — задержка (пауза)
  // tag        — тег/сегмент
  // action     — webhook/CRM-действие
  // handoff    — передать оператору (конец для бота)
  // end        — конец ветки

  /**
   * Запустить воронку для пользователя
   * @param {Object} funnel — воронка { id, blocks, connections }
   * @param {string} userId — Telegram ID пользователя
   * @param {Object} context — доп. информация (канал, имя и т.д.)
   * @returns {Object} — первый блок для выполнения
   */
  async startFunnel(funnel, userId, context = {}) {
    const trigger = funnel.blocks.find(b => b.type === 'trigger');
    if (!trigger) throw new Error('Воронка не имеет блока Старт');

    // Сохраняем состояние
    const state = {
      funnelId: funnel.id,
      userId,
      currentBlockId: trigger.id,
      completedBlocks: [],
      context,
      startedAt: Date.now(),
      data: {} // данные, собранные по ходу (ответы, теги и т.д.)
    };

    await this.storage.set(`funnel:${userId}:${funnel.id}`, JSON.stringify(state));
    await this.storage.set(`funnel:${userId}:active`, funnel.id);

    return this.executeBlock(trigger, state);
  }

  /**
   * Продолжить воронку после ответа пользователя
   * @param {string} userId
   * @param {string} userMessage — текст ответа пользователя
   * @param {string} [funnelId] — если не указан, берётся активная воронка
   */
  async continueFunnel(userId, userMessage, funnelId = null) {
    if (!funnelId) {
      funnelId = await this.storage.get(`funnel:${userId}:active`);
      if (!funnelId) return null; // нет активной воронки
    }

    const stateRaw = await this.storage.get(`funnel:${userId}:${funnelId}`);
    if (!stateRaw) return null;
    const state = JSON.parse(stateRaw);
    const funnel = this._findFunnel(funnelId);
    if (!funnel) return null;

    // Сохраняем ответ пользователя
    state.data[`answer_${state.currentBlockId}`] = userMessage;

    // Ищем следующий блок
    const currentBlock = funnel.blocks.find(b => b.id === state.currentBlockId);
    if (!currentBlock) return null;

    const nextBlock = this._findNextBlock(funnel, currentBlock, userMessage, state);
    if (!nextBlock) return null;

    state.completedBlocks.push(state.currentBlockId);
    state.currentBlockId = nextBlock.id;

    await this.storage.set(`funnel:${userId}:${funnelId}`, JSON.stringify(state));

    return this.executeBlock(nextBlock, state);
  }

  /**
   * Выполнить блок и вернуть ответ для пользователя
   */
  executeBlock(block, state) {
    const result = {
      blockId: block.id,
      type: block.type,
      title: block.title,
      content: block.content,
      buttons: null,
      fileUrl: null,
      delay: null,
      isEnd: false,
    };

    switch (block.type) {
      case 'trigger':
        result.content = block.content || 'Добро пожаловать!';
        break;

      case 'message':
        result.content = block.content || '';
        break;

      case 'buttons':
        result.content = block.content || 'Выберите вариант:';
        result.buttons = this._parseButtons(block);
        break;

      case 'leadmagnet':
        result.content = block.content || 'Вот ваш материал:';
        // TODO: прикрепить реальный файл
        break;

      case 'condition':
        result.content = block.content || 'Жду ответ…';
        break;

      case 'payment':
        result.content = block.content || 'Ссылка на оплату:';
        // TODO: generate payment link
        break;

      case 'delay':
        result.delay = parseInt(block.content) || 300000; // 5 минут по умолчанию
        result.content = null; // не отправляем сообщение, просто ждём
        break;

      case 'tag':
        result.content = null; // тихо присваиваем тег
        break;

      case 'handoff':
      case 'end':
        result.content = block.content || 'Спасибо! Мы с вами свяжемся.';
        result.isEnd = true;
        break;
    }

    return result;
  }

  /**
   * Найти следующий блок по связям
   */
  _findNextBlock(funnel, currentBlock, userMessage, state) {
    const connections = funnel.connections.filter(c => c.from === currentBlock.id);

    if (connections.length === 0) return null;
    if (connections.length === 1) {
      return funnel.blocks.find(b => b.id === connections[0].to);
    }

    // Если несколько связей — выбираем по условию/порту
    for (const conn of connections) {
      if (conn.fromPort === 'yes' || conn.fromPort === 'paid') {
        // Условие "Да" / "Оплатил" — проверяем
        if (this._checkCondition(currentBlock, userMessage, conn.fromPort)) {
          return funnel.blocks.find(b => b.id === conn.to);
        }
      } else if (conn.fromPort === 'no' || conn.fromPort === 'unpaid') {
        // Условие "Нет" / "Не оплатил"
        if (!this._checkCondition(currentBlock, userMessage, conn.fromPort)) {
          return funnel.blocks.find(b => b.id === conn.to);
        }
      } else if (conn.fromPort === 'out') {
        return funnel.blocks.find(b => b.id === conn.to);
      }
    }

    return null;
  }

  _checkCondition(block, userMessage, port) {
    // Простейшая проверка: для "Да" ищем положительные слова
    if (port === 'yes' || port === 'paid') {
      const positive = ['да', 'да', 'yes', 'ага', '+', '1', 'конечно', 'хорошо', 'ок', 'ok', 'оплатил', 'оплачено'];
      return positive.some(w => userMessage.toLowerCase().includes(w));
    }
    if (port === 'no' || port === 'unpaid') {
      const negative = ['нет', 'no', 'не', '-', 'пока нет', 'отказ'];
      return negative.some(w => userMessage.toLowerCase().includes(w));
    }
    return false;
  }

  /**
   * Парсит кнопки из блока
   */
  _parseButtons(block) {
    // Кнопки можно хранить в content как JSON строку или в отдельном поле
    try {
      const parsed = JSON.parse(block.content || '[]');
      return Array.isArray(parsed) ? parsed : null;
    } catch {
      return null;
    }
  }

  /**
   * Найти воронку по ID (заглушка — реальная имплементация через storage)
   */
  _findFunnel(funnelId) {
    // В реальности — запрос к БД
    return null;
  }

  /**
   * Отметить воронку как завершённую
   */
  async finishFunnel(userId, funnelId) {
    await this.storage.del(`funnel:${userId}:${funnelId}`);
    await this.storage.del(`funnel:${userId}:active`);
  }
}

module.exports = FunnelEngine;
